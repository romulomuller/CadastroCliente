
package cadastrocliente;
import java.util.ArrayList;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
              
        ArrayList<Cliente> arrayList = new ArrayList<Cliente>();
        
            for(int i=0; i<2; i++) {
                  System.out.println("Escolha uma opção desejada:");
                  System.out.println("1 - Cadastrar novo cliente");
                  System.out.println("2 - Imprimir lista");
                  System.out.println("3 - Sair");
                  int escolha = leitor.nextInt();
                           
                switch(escolha) {
                    case 1:
                 
                        System.out.println("Informe o nome do cliente:");
                        String nome = leitor.next();
                        System.out.println("Informe a data de nascimento:");
                        String dataNascimentoRecebida = leitor.next();
                        System.out.println("Informe o telefone:");
                        String altura = leitor.next();
                        
                        Cliente pessoa = new Cliente(nome, dataNascimentoRecebida, altura);
                        arrayList.add(pessoa);
                           i=0;
                        break;
                        
                    case 2:
                           for (int y = 0; y<arrayList.size(); y++) {
                              System.out.println(arrayList.get(y));
                           }
                            i = 0;
                        break;
                        
                   default:
                        i = 3;
                }
            }
     }
}
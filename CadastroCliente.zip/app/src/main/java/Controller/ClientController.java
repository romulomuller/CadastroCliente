
package Controller;

import Model.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Util.ConnectionFactory;
import java.io.FileWriter;
import java.io.PrintWriter;

public class ClientController {
    
    public void save (Cliente cliente) {
        
        String sql = "INSERT INTO cliente (nome,  telefone, dataNascimento) VALUES (?, ?, ?)";
        
        Connection conn = null;
        PreparedStatement stmt = null;
    
        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, cliente.getNome());
            stmt.setString(2, cliente.getTelefone());
            stmt.setString(3, cliente.getDataNascimento());
            stmt.execute();
        } catch (SQLException ex) {
            throw new RuntimeException("Erro ao salvar a tarefa " + ex.getMessage(), ex);
        } finally {
            ConnectionFactory.closeConnection(conn, stmt);
        }
    }
    
    public List <Cliente> getAll () {
        String sql = "SELECT * FROM cliente";
        
        List <Cliente> listaCliente = new ArrayList<>();
        
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet resultSet = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);
   //         stmt.setInt(1, numeroCadastro);
            resultSet = stmt.executeQuery();
      
            while (resultSet.next()) {
            
                Cliente cliente = new Cliente();
                cliente.setNumeroCadastro(resultSet.getString("numeroCadastro"));
                cliente.setNome(resultSet.getString("nome"));
                cliente.setTelefone(resultSet.getString("telefone"));
                cliente.setDataNascimento(resultSet.getString("dataNascimento"));
                listaCliente.add(cliente);
                
                
                
                
                
            } 
            
            try {
                    FileWriter arq = new FileWriter("C:\\Users\\romulomuller\\Desktop\\cadastroCliente.txt");
                    PrintWriter gravarArq = new PrintWriter(arq);
                    gravarArq.println("Nome      /Telefone    /Data nascimento");
              //      gravarArq.println("ovo");     
                    for (int y = 0; y<listaCliente.size(); y++) {           
                        gravarArq.println(listaCliente.get(y));      
                           }                                                                            
                           arq.close();
                } catch (Exception ex) {
             throw new RuntimeException("Erro ao gerar txt " + ex.getMessage(), ex);
         }
            
         } catch (SQLException ex) {
             throw new RuntimeException("Erro ao buscar tarefas " + ex.getMessage(), ex);
         } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                throw new RuntimeException("Erro ao fechar a conex�o", ex);
            }      
        }
       return listaCliente;
            
                            
    } 
    
}

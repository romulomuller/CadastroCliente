package Model;

public class Cliente {
        
    private String numeroCadastro;
    private String nome;
    private String telefone;
    private String dataNascimento;
    
    //construtor
    public Cliente (String nome, String telefone, String dataNascimento) {
        this.nome = nome;
        this.telefone = telefone;
        this.dataNascimento = dataNascimento;
    }
    
    public Cliente (String numeroCadastro, String nome, String telefone, String dataNascimento) {
        this.numeroCadastro = numeroCadastro;
        this.nome = nome;
        this.telefone = telefone;
        this.dataNascimento = dataNascimento;
    }
    
     public Cliente () {
        
    }

    //getters and setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public String getNumeroCadastro() {
        return numeroCadastro;
    }

    public void setNumeroCadastro(String numeroCadastro) {
        this.numeroCadastro = numeroCadastro;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }
           
    //metod

    @Override
    public String toString() {
        return   nome + " / " + telefone + " / " + dataNascimento;
    }
    
    
    
}
